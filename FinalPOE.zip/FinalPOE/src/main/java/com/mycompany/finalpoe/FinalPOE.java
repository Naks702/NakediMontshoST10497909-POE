
package com.mycompany.finalpoe;
public class FinalPOE {
    public static void main(String[] args) {

      
         LoginsnReg logins = new LoginsnReg();
        logins.startLoginProcess(0);
        Message message = new Message();
        
        //upon successful the app present the message send functionality
        message.numericMenu();

  
       
}
    }

