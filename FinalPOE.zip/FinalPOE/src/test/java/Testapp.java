/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */

import com.mycompany.finalpoe.LoginsnReg;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class Testapp {
     private LoginsnReg login;
    public Testapp() {
    }

 @Test
public void CheckUserName() {
assertTrue(login.checkUserName("kyl_"), "Username with _ and <= 5 chars should be valid");
 }

//@Test
//public void testCheckUserName_Invalid() {
//assertFalse(login.checkUserName("abcdef"), "Username without _ or > 5 chars should be invalid");
//}
//
//@Test
//public void testCheckPassword_Valid() {
//assertTrue(login.checkPassword("Ch&&sec@ke99!"), "Password meets all requirements");
//}
//
//@Test
//public void testCheckPassword_Invalid() {
//assertFalse(login.checkPassword("password"), "Password lacks uppercase, digits, and special characters");
// }
//
//@Test
//public void testCheckCellPhoneNumber_Valid() {
//assertTrue(login.checkCellPhoneNumber("+27838968976 "), "Valid +27 cellphone number");
//}
//
//@Test
//public void testCheckCellPhoneNumber_Invalid() {
//assertFalse(login.checkCellPhoneNumber("0896655302"), "Should start with +27 and be 12 digits");
// }
//
//@Test
//public void testLoginUser_Success() {
//LoginsnReg.userCredentials.put("user1", "Pass@1234");
//assertTrue(login.loginUser("user1", "Pass@1234"));
//}
//
//@Test
//public void testLoginUser_Failure() {
//LoginsnReg.userCredentials.put("user2", "Pass@1234");
//assertFalse(login.loginUser("user2", "wrongpass"));
//}
//
//@Test
//   public void testReturnLoginStatus_Success() {
//LoginsnReg.userCredentials.put("admin", "Admin@2024");
//assertEquals("Successful login", login.returnLoginStatus("admin", "Admin@2024"));
//}
//
//@Test
//public void testReturnLoginStatus_Failure() {
//assertEquals("Failed login", login.returnLoginStatus("nonuser", "nope"));
//  }

//@Test
//public void handleMessageOption(){
//    
//}
//@Test
//public void testcreateMessageHash(){
//    
//}
//@Test
//public void teststoreMessages(){
//    
//}
//@Test
//public void testloadMessages(){
//    
//}
//@Test
//      public void  testexcutiveReport(){
//            
//        }
//      @Test
//       public void testsenderRecipientReport(){
//           
//       }
//       @Test
//       public void testsentMessages(){
//           
//       }
//       @Test
//       public void longestMessage(){
//           
//       }
//       @Test
//       public void  searchMessagesById(){
//           
//       }
}